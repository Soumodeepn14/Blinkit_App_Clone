import 'package:flutter/material.dart';

class AppColors{
  static const Color scaffoldbackground=Color(0XFFf7CB45);
}